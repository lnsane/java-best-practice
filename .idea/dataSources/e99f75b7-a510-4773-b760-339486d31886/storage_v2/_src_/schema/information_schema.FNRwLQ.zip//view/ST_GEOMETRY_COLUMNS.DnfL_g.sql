create view ST_GEOMETRY_COLUMNS as
select `cols`.`TABLE_CATALOG` AS `TABLE_CATALOG`,
       `cols`.`TABLE_SCHEMA`  AS `TABLE_SCHEMA`,
       `cols`.`TABLE_NAME`    AS `TABLE_NAME`,
       `cols`.`COLUMN_NAME`   AS `COLUMN_NAME`,
       `srs`.`SRS_NAME`       AS `SRS_NAME`,
       `cols`.`SRS_ID`        AS `SRS_ID`,
       `cols`.`DATA_TYPE`     AS `GEOMETRY_TYPE_NAME`
from (`information_schema`.`COLUMNS` `cols`
         left join `information_schema`.`ST_SPATIAL_REFERENCE_SYSTEMS` `srs` on ((`cols`.`SRS_ID` = `srs`.`SRS_ID`)))
where (`cols`.`DATA_TYPE` in
       ('geometry', 'point', 'linestring', 'polygon', 'multipoint', 'multilinestring', 'multipolygon',
        'geomcollection'));

