create view TABLE_CONSTRAINTS as
(select `cat`.`name`                                                AS `CONSTRAINT_CATALOG`,
        `sch`.`name`                                                AS `CONSTRAINT_SCHEMA`,
        convert(`idx`.`name` using utf8)                            AS `CONSTRAINT_NAME`,
        `sch`.`name`                                                AS `TABLE_SCHEMA`,
        `tbl`.`name`                                                AS `TABLE_NAME`,
        if((`idx`.`type` = 'PRIMARY'), 'PRIMARY KEY', `idx`.`type`) AS `CONSTRAINT_TYPE`
 from (((`mysql`.`indexes` `idx` join `mysql`.`tables` `tbl` on ((`idx`.`table_id` = `tbl`.`id`))) join `mysql`.`schemata` `sch` on ((`tbl`.`schema_id` = `sch`.`id`)))
          join `mysql`.`catalogs` `cat`
               on (((`cat`.`id` = `sch`.`catalog_id`) and (`idx`.`type` in ('PRIMARY', 'UNIQUE')))))
 where (can_access_table(`sch`.`name`, `tbl`.`name`) and is_visible_dd_object(`tbl`.`hidden`, `idx`.`hidden`)))
union
(select `cat`.`name`                    AS `CONSTRAINT_CATALOG`,
        `sch`.`name`                    AS `CONSTRAINT_SCHEMA`,
        convert(`fk`.`name` using utf8) AS `CONSTRAINT_NAME`,
        `sch`.`name`                    AS `TABLE_SCHEMA`,
        `tbl`.`name`                    AS `TABLE_NAME`,
        'FOREIGN KEY'                   AS `CONSTRAINT_TYPE`
 from (((`mysql`.`foreign_keys` `fk` join `mysql`.`tables` `tbl` on ((`fk`.`table_id` = `tbl`.`id`))) join `mysql`.`schemata` `sch` on ((`tbl`.`schema_id` = `sch`.`id`)))
          join `mysql`.`catalogs` `cat` on ((`cat`.`id` = `sch`.`catalog_id`)))
 where (can_access_table(`sch`.`name`, `tbl`.`name`) and is_visible_dd_object(`tbl`.`hidden`)));

